# 规则引擎现场验收报告

日期：2026-11-18
环境：`cu04`（Gaussian 16 Rev A.03）+ `mu01`（Python 3.12.7 跑规则引擎）
日志来源：**全部由本机通过 SSH 在 cu04 上真实运行 Gaussian 生成**，不是合成或改写的。

---

## 一句话结论

28 份真实 Gaussian 日志，**27 份判定符合预期，1 份漏判**。
漏的那一份恰恰是最危险的一类错：Gaussian 正常终止、报告显示一切正常，但算的根本不是你要的分子。
另外暴露出 1 条规则缺口（已补）、1 处**我自己编造的病因说明**（已更正）。

收尾时还发现同一个错误在我自己的评估工具里犯了三次：**把「正常终止」当成「结果正确」**，
导致真阳性被记成误报、样本集自相矛盾、曲线把不能用的计算标成可用（均已修，见第九节补记）。
这个错误值得单拎出来说，因为它正是这套系统存在的理由——如果「没崩就等于对」，
那评测本身就是多余的。

---

## 一、这次和以前的测试有什么不同

之前 `tools/eval_rules.py` 那套样本，本质是"从我手上的日志嫁接/变异出题目，再用我的引擎去答"。
本次换成第三方的、真实跑出来的日志：

| | 以前的样本 | 本次 |
|---|---|---|
| 日志从哪来 | cclib 仓库的真实日志 + 我手工嫁接错误块 | cu04 上现跑，含真实段错误、真实 SIGKILL |
| 失败怎么产生 | 把官方错误文本插进正常日志 | 真的把 Gaussian 弄崩（非法基组、1MB 内存、坐标重合…） |
| 预期怎么定 | 我知道每条样本埋了什么 | 先按构造意图写预期，跑完对比 |

服务器链路（实测，与交接文档略有出入）：

- `mu01` 上 `/nfs-cu07-1` 是 NFS4 挂载，可读写 → 不需要 `scp -3` 绕道，直接以 mu01 为中转。
- `mu01 → cu07/cu04/cu02` 全部免密。
- **`cu04` 的 Python 是 3.6.8 且无 PyYAML**，跑不了本仓库代码（需要 3.10+ 语法）。
  所以 Gaussian 留在 cu04，规则引擎在 mu01 上跑。

产物目录：`/nfs-cu07-1/mqh/qchem-eval-verify/`

---

## 二、结果总览

```
符合预期 27 / 28
```

| 类别 | 份数 | 结果 |
|---|---|---|
| 正常计算（不应误报） | 13 | 12 份无 critical/major（最高 95 分 minor 提示）；1 份该报 major（`ok_link2_diff` 段间换基组，见第五节 E-08） |
| 真实崩溃（必须判 FAIL） | 10 | 全部 FAIL，失败类型认得准 |
| 特殊场景 | 5 | 4 份符合，1 份漏判（见 P0） |

### 崩溃类全部命中，且失败类型没认错

| 日志 | 构造方式 | 判定 | 命中 |
|---|---|---|---|
| `fail_atom_overlap` | 两原子坐标重合 | FAIL 60 | A-01 |
| `fail_bad_basis` | 基组名 `NOT-A-BASIS` | FAIL 60 | A-01 |
| `fail_charge_parity` | 16 电子声明二重态 | FAIL 20 | A-01 + **E-04** |
| `fail_chk_read` | `guess=read` 但无 chk | FAIL 55 | A-01 |
| `fail_mem_low` | `%mem=1MB` | FAIL 60 | A-01 |
| **`fail_nproc`** | `%nprocshared=9999` | FAIL 60 | A-01 + SIG-NOTERM |
| `fail_opt_maxcyc` | `opt=(maxcyc=1)` | FAIL 20 | **A-05** |
| `fail_scf_maxcyc` | `scf=(maxcyc=1)` | FAIL 0 | **A-02** + A-06 |
| `fail_zmat_eof` | 输入缺末尾空行 | FAIL 20 | A-01 + SIG-IN-3 |
| `sp_killed` | 真 SIGKILL（exit 137） | FAIL 0 | A-01，覆盖率 0.528 |

两点值得单说：

**`fail_nproc`**：Gaussian 打印完 `Will use up to 9999 processors via shared memory.` 就
**静默停住了**，日志里既没有 `Normal termination` 也没有 `Error termination`。
纯靠官方错误目录的方案在这里会完全失明。它被判 FAIL 是因为有 SIG-NOTERM 兜底。

**`sp_killed`** 覆盖率只有 0.528，18 条规则判 UNKNOWN。这是对的 —— 日志被砍断，一半的检查项
确实没数据可依。它没有硬凑出一个高分。

---

## 三、P0：唯一漏判的那一份

### `fail_coord_missing` —— 判 PASS 100 分

构造：route 写 `#p B3LYP/6-31G(d)`（意图是算水分子），但坐标块只写了一行 `O 0 0 0`。

Gaussian 的反应是：

```
 Charge =  0 Multiplicity = 1
 NAtoms=      1
 Standard basis: 6-31G(d) (6D, 7F)
 SCF Done:  E(RB3LYP) =  -74.9573967759     A.U. after    8 cycles
 ...
 Normal termination of Gaussian 16
```

它把这份输入当成**单原子氧**，算得干干净净、正常终止、能量看着也像模像样。
规则引擎给出 **PASS 100 分，零 finding**。

### 为什么判不出来

日志里**不存在**"本来应该有 3 个原子"这个信息。`NAtoms=1` 是事实，元素列表是 `[O]`，
两者一致，E-03（原子数与元素列表不一致）无从触发。任何只看单份输出日志的工具都会漏。

这不是实现 bug，是**能力边界**：单文件自检看不到"输入声明"与"实际执行"之间的落差。

### 怎么修

需要输入文件参与：

```bash
qchem-eval judge out.log --input in.gjf
```

对比三件事，任一不符就是 critical：

| 对比项 | 输入侧 | 输出侧 |
|---|---|---|
| 原子数 | 坐标块行数 | `NAtoms=` |
| 电荷 / 多重度 | 坐标块前一行 | `Charge = x Multiplicity = y` |
| route | `#p ...` 行 | 日志回显的 route |

同类还能顺带抓：坐标行数与元素不匹配、`--Link1--` 里第二段的设定和第一段不同、
输入说 `opt` 而日志只做了 `sp`。

**这条还没实现**，等你点头我再动 —— 它要改 CLI 接口（`judge` 多一个可选参数）。

---

## 四、P1：已修的两处

### 1. 补规则 B-09：声称优化过渡态，但频率全为正

构造：`#p B3LYP/6-31G(d) opt=(ts,calcfc,noeigentest) freq`，优化 HCN。

Gaussian 的结果是**收敛到极小点**：

```
Low frequencies ---   -0.0012 -0.0012 -0.0004  9.1099  9.1099  767.8672
Frequencies --   767.8664   767.8664   2213.9911
Frequencies --  3478.5600
```

一个虚频都没有。原因是我加了 `noeigentest` —— 它让 Gaussian 在找不到负本征值
时也判收敛。用户会以为拿到了过渡态，实际拿到的是极小点。

旧规则集对此判 **PASS 100 分**，因为 B-01/B-02 只问"有几个虚频"，不问"你要的到底是什么"。

新增 B-09（major）：`route 声明 opt=ts` + `n_imag == 0` → 命中。现在判 **WARNING 85 分**。
正样本直接用这份真实日志（`tests/data/ts_no_imag.log`），没造假。

### 2. 更正 C-07 的病因说明 —— 我上一轮编错了

上一轮我把 `demo/wrong_basis.out` 的现象（route 写 `sto-3g`、`Standard basis` 是 `6-31G(d)`）
解释成"`geom=allcheck` + `guess=read` 让 chk 覆盖了 route 的基组"，还把这个说法写进了修复建议。

本次实测推翻它：`sp_allcheck_step2` 用同样的 `guess=read geom=allcheck`，
`Standard basis` 就是 route 里声明的 **STO-3G**。chk 不覆盖基组。

真正的答案更朴素：`demo/wrong_basis.out` 是 cclib `dvb_sp.out` 的副本，
那一行 `Standard basis` 被人为改过（原版是 `STO-3G`）。它是**构造样本**，不是真实运行产物。
我拿一份假日志当证据，给一条规则编了一个病因。

C-07 保留（它检测"声明 ≠ 实际"这个现象仍成立），但修复建议已改成诚实的排查方向，
README 里那段也改成了反面教材。

**教训**：日志现象 ≠ 成因。没复现过的因果链，不该写成用户建议。

---

## 五、P2：噪音与措辞（E-08 已修，其余待办）

### E-08 对 `opt freq` 每次都命中（已修，v0.6）

`opt freq` 在 Gaussian 内部必然拆成两段 link1，于是 `n_jobs=2`，
E-08「单文件内含多段 link1 作业」每次都会响。
`ok_water_optfreq`、`ok_ts`、`ok_link1` 全中。级别是 info，不影响结论，
但它是噪音 —— 真正该警惕的是「两段的方法/基组不同」。

**改法**：解析器现在收集**每一段** route 声明的方法/基组，归一化（剥 R/U 自旋前缀）
后去重；E-08 改成「去重后 ≥ 2 种才报」，级别 info → major。判「单段作业」用
`applies: n_jobs >= 2`（不适用就该 na，不进覆盖率分母），不放进 when。

改这条时踩了两个坑，都是"静默"型的：

1. **归一化本身失效**。`_strip_spin_prefix` 只判大写前缀，而 route 是先小写再进来的，
   于是第二段的 `RB3LYP` 归一化成 `rb3lyp`，被当成"换了泛函"。现象是**正常日志误报**，
   比不归一化更难发现。补大小写识别，同时把 `revPBE / r2SCAN / RPBE / RO*` 排除在外
   —— 那几个开头的 r 不是自旋前缀，剥掉就变成另一个方法了。
2. **顺手覆盖掉了已有字段**。加 `route_methods` 时把 `route_basis` 的声明行删了。
   dataclass 没有 slots，`d.route_basis = ...` 照样赋值成功、`vars(d)` 照样取到、
   59 个测试全绿 —— 字段声明没了这件事没有任何表现。已补回。

**cu04 实测（真 Gaussian 16 Rev A.03）**：新增 `ok_link2_diff.gjf`（首段 `HF/STO-3G`、
第二段 `B3LYP/6-31G(d)`），跑出来的日志里两段的 route 是

```
 84: #p HF/STO-3G
390: #p B3LYP/6-31G(d)
```

Gaussian 对显式 `--Link1--` 的段**原样回声**用户写的那行，不会补 R 前缀、不会重排关键字；
补 R 前缀只发生在它自己拆出来的段（`opt freq` 的第二段）。两种形态解析器都覆盖了。
验收结果：`ok_link1`（两段同为 HF/STO-3G，95 分，E-08 不响）/ `ok_link2_diff`（85 分，E-08 命中）。

**顺带发现的另一个问题：C-07 与 E-08 同因双罚。** `ok_link2_diff` 同时命中
C-07「route 声明的基组 ≠ 实际使用的基组」—— 因为 C-07 拿**首段**声明比**末段**实际，
多段作业里必然不等。同一处缺陷扣两次分（85 → 70）。已给 C-07 加
`applies: n_route_methods <= 1`：它只负责「全文只声明了一种方法时的声明/实际不符」，
跨段换方法是 E-08 的地盘。

### C-08 的"有机体系"表述对 H2 也成立

`ok_h2_sp` 用 STO-3G，命中 C-08「有机体系使用不含极化函数的基组」。
H2 谈不上"有机体系"。命中的**结论**没错（STO-3G 确实不该用来出结论），但**措辞**失准。
它对 `fail_chk_read`、`ok_link1` 也同样命中。

### 嗅探只看前 64KB

`adv_long_line`（前面塞了 2MB 垃圾行）→ `dispatch` 认不出格式 → 判 UNKNOWN 0 分。
它**没有静默**，给出了「无法识别输出文件格式，未解析任何字段」，所以是合格降级。
但如果日志被 append 到已有长文件后面，就会漏判。改进办法是嗅探失败后按块跳读，
成本是每次多读几十 KB。

---

## 六、对抗测试：13 种畸形输入，0 次崩溃

| 样本 | 判定 | 评价 |
|---|---|---|
| `adv_crlf`（CRLF 换行） | PASS | 正确 |
| `adv_no_final_nl`（无结尾换行） | PASS | 正确 |
| `adv_g09_label`（伪装成 G09） | PASS | 不依赖版本字符串 |
| `adv_latin1`（非 UTF-8 字节） | PASS | 正确 |
| `adv_concat`（两份日志拼接） | PASS | 内容确实完整，判 PASS 合理 |
| `adv_binary_noise`（混入 4KB 随机字节） | PASS | 关键行未被破坏；但耗时 127ms（正常 6ms） |
| `adv_trunc_15` | FAIL 40 | 正确，覆盖率 0.56 |
| `adv_trunc_50` | FAIL 0 | 正确 |
| `adv_trunc_90` | PASS | 正确 —— 截断点在 `Normal termination` **之后** |
| `adv_empty`（0 字节） | UNKNOWN 0 | 正确，没判 PASS |
| `adv_only_header`（只有版权头） | FAIL 60 | 正确 |
| `adv_fragment`（只剩错误块） | FAIL 60 | 正确 |
| `adv_long_line`（2MB 单行） | UNKNOWN 0 | 合格降级，有明确诊断 |

**没有一个变体抛未捕获异常**，也没有一个畸形输入被判成 PASS（除了内容真的完整的两个）。
这是"缺数据不等于通过"这条设计原则最直接的验证。

---

## 七、性能

在 mu01 上、27 份真实日志（E-08 那轮之前）：

```
冷启动（规则集 + 签名库首次加载）  114.9 ms   ← 只发生一次
热态 27 份合计                    51.2 ms
平均                             1.90 ms / 份
最大（6973 行 / 377KB）           10.31 ms
```

**注意**：第一次跑出来的数字是"平均 6.29ms、最大 117ms"，看着像有性能悬崖。
查下来是 `fail_atom_overlap.log` 按字母序第一个被处理，承担了冷启动那 115ms。
真实热态是 1.90ms。测量脚本必须先预热 —— 这和 README 里"`load_signatures()` 预热必须在
`t0` 之前"是同一个坑，我又踩了一次。

---

## 八、跨阶段对比（真实日志）

| 组 | 结果 |
|---|---|
| `ok_water_opt` ↔ `ok_water_optfreq`（同水平 opt 末 vs optfreq 末） | ΔE = **+0.00** kcal/mol，方法一致 → WARNING 95（差异来自 A 侧的 E-01） |
| `sp_allcheck_step1`(6-31G(d) opt) ↔ `sp_allcheck_step2`(STO-3G sp) | ΔE = **-686.14** kcal/mol，方法不一致 → **FAIL 35** |

同一水平的两份日志能量对得上，不同水平的一眼看出差 686 kcal/mol。这块工作正常。

---

## 九、我自己犯的错（一并记录）

1. **C-07 病因编造** —— 见第四节。最严重，因为它进了给用户的修复建议。
2. **预期表写错 3 处**：
   - 以为 `guess=read` 会让 chk 覆盖基组（错，见上）
   - 以为 O2 三重态有显著自旋污染（实测 S²=2.0065，几乎没有，C-02 不命中是**对的**）
   - 以为 `opt=ts` 必然产出虚频（实测 `noeigentest` 会让它收敛到极小点，这反而暴露了 B-09 缺口）
3. **构造 Gaussian 输入踩了 4 次格式坑**：坐标块后必须空行（否则 `End of file in ZSymb`
   + 段错误）、gen 基组段间不能有空行（`****` 才是分隔符）、同一元素的多个 shell 要在
   同一个块里、基组末尾要有空行（`End of file reading basis center`）。
4. **手写 DVB 结构只写了 3 个 H**，导致 63 电子配单重态 —— 于是 `sp_killed` 里 E-04 命中，
   我一度以为是误报，查下来是我的输入本身违法。

第 2 条说明一件事：**我的"预期"和引擎的判断冲突时，不一定是我对**。
所以预期表里每一处改动我都留了注释说明"这条是跑完之后改的"，没有偷偷回填。

### 补记：收尾时发现，同一个错误在三个地方各犯了一次

补 B-09 之后本机全量回归挂了 1 个用例。顺着查下去，发现真正的问题不在测试，
而是**我把「正常终止」当成了「结果正确」**——这个错误在三个文件里换了三种形态：

| 位置 | 错误形态 | 后果 |
|---|---|---|
| `tools/eval_rules.py` | `DATA.glob("*")` 全量当「真实成功日志」 | B-09 在 `ts_no_imag.log` 上命中 → 被记成**高严重性误报**，真阳性算成假阳性 |
| `tools/synth_failures.py` | 同一份文件既登记为 `realpos:B-09` 正样本，又登记为「真实成功计算」负样本 | 样本集**自相矛盾**，同一个文本一个标签说好一个说坏 |
| `tools/risk_coverage.py` | `unusable` 由 `severity == critical` 推出，B-09 是 major | 曲线把这份不能用的计算标成「可用」，高分段凭空多一个漏放，看着像排序失效 |

三处的修法是同一件事：**把「可用 / 不可用」变成显式标注，而不是从别的信号推**。

- `REAL_OK`（7 份，结果可用）与 `REAL_BAD`（1 份，正常终止但答案是错的）分开声明。
- `assert_real_logs_classified()` 保证 `tests/data` 下每份日志都被显式判过。
  没判过就**抛错**，不许「不在 REAL_OK 里就当不可用」——那样新增日志忘了登记，
  检查范围会悄悄变窄，而报告上依旧 100%。
- risk-coverage 里不可用的判定改为「severity 是 critical **或** 内容命中 `REAL_BAD`」，
  按内容哈希而不是文件名，因为同一份文本会以两种身份进样本集、去重时谁先到谁当代表。

修完之后曲线**自己把问题指出来了**：

```
前 50% 里漏掉的不可用样本（1 个）：
    realpos:B-09    pass_with_warning   score=85   命中=B-09,E-08
```

全样本里就这一个漏放，而且它正是那份真实跑出来的错误过渡态。这不是噪音，
是 B-09 定级该不该从 major 提到 critical 的证据——**这个定级我没动，等你判断**：
提到 critical 会把 score 压到不通过区间，代价是更多「其实没错」的体系进人工复核。

顺带修了一个测试自身的问题：`test_parser_beats_cclib_on_speed` 用**单次计时**配硬阈值，
全量跑时偶发失败两次（单独跑必过）。改成取 6 次里的最小值——干扰只会让耗时变长，
最小值才是「这台机器做这件事要多久」的稳定估计。偶发失败的护栏最后都会被人注释掉，
那还不如不写。

---

## 附：结构错误的专项实测（6 种明显错的结构）

前面测的都是「Gaussian 层面出问题」。但用户更常犯的是另一种错：**结构本身写错了**。
专门造了 6 个错得离谱的输入，在 cu04 上真跑（`field_test/server/gen_badgeom.py`）。

| 错误结构 | Gaussian 的反应 | 补 B-10 前 | 补 B-10 后 |
|---|---|---|---|
| 两个 H 坐标完全重合 | **拒算**：`Atoms too close.` + 段错误 | FAIL 60 | FAIL 60 ✓ |
| 甲烷里两个 H 重合 | **拒算**：`Problem with the distance matrix` | FAIL 20 | FAIL 20 ✓ |
| H2 键长写成 5.0 Å | 算完，正常终止，E = -0.599 | WARNING **90** | WARNING **75**（命中 B-10） |
| 水三原子排成直线 | 算完，正常终止，E = -74.85 | WARNING 95 | WARNING 95（仍漏） |
| 想做水但把 O 写成 C | 算完（算的是 CH2），E = -38.32 | WARNING 95 | WARNING 95（原理上判不出） |
| 水配 +1 电荷 | 算完（算的是 H₂O⁺，合法输入） | WARNING 95 | 同左，这条不算错 |

**分界线很清楚：错到 Gaussian 不肯算的，全都抓得住；错得它愿意算的，基本抓不住。**

前两类之所以抓得住，其实不是引擎聪明——Gaussian 自己就报错拒算了，引擎只是把
`Atoms too close.` 读懂。真正缺的是后几类：Gaussian 正常终止、SCF 收敛、能量也是
个像样的数字，日志里挑不出一句毛病，因为**日志里根本没有「这个结构本该长什么样」**。

B-10 就是为这一类补的：用共价半径把末帧几何切成连通片段，片段间距超过 4.5 Å
就判「散架」。阈值取 4.5 的依据是正常分子间作用力的上界（氢键 1.5–2.2、π 堆积
3.3–3.8、范德华接触约 4.0），超过之后两个片段之间已无化学作用。

验证结果：H2@5Å 被切成 2 个片段、间距 5.00 → 命中；**9 份真实日志全部 1 个片段，
零误报**；risk-coverage 上前 50% 的漏放仍然只有 B-09 那一个，说明 B-10 没有制造新的漏放。

还有两条没补，理由不同：

- **水三原子共线**：技术上能查（键角 180°），但 CO₂、HCN、乙炔本来就是直线的，
  写不好就是一片误报。要等真实踩坑案例再定判据。
- **把 O 写成 C**：原理上判不出来。引擎没有任何途径知道「用户本来想要氧」，
  输入文件里写的也是 C。**它判断的是「你算的这个东西算得对不对」，不是
  「你算的是不是你想算的」**——后一个问题只能靠人和人的沟通。

**B-10 的阈值有实测护栏。** 刚写完 B-10 时，验证集里一份真正的复合物都没有，
所以「复合物不会误报」只是物理推理。后来专门在 cu04 上跑了三个体系补上这一半：

| 体系 | 片段数 | 片段间距 | B-10 | 预期 |
|---|---|---|---|---|
| 水二聚体（O···O 文献值 2.98 Å） | 2 | 2.98 Å | 不报 | 不报 ✓ |
| 苯二聚体（平行堆积 3.4 Å） | 2 | 3.46 Å | 不报 | 不报 ✓ |
| 两个 H₂ 相距 10 Å（故意的非相互作用极限） | 2 | 9.26 Å | **报** | 报 ✓ |

3/3 符合预期。注意中间那一栏：三个体系**都被正确切成 2 个片段**——说明切分逻辑
本身不区分复合物和散架，区分完全靠 4.5 Å 这道距离门槛。阈值余量：最接近的
苯二聚体是 3.46，距门槛还有 1.04 Å。

前两个体系已收进 `tests/data/`（`water_dimer.log` / `benzene_dimer.log`），
作用是给阈值上锁：谁把 4.5 改到 3.0 附近，苯二聚体立刻就红。
第三个没进回归集，因为它的「好坏」取决于用户意图（BSSE 校正用它是合法的），
硬贴一个标签反而会把 `REAL_OK` / `REAL_BAD` 的语义搅浑。

**还剩一个真盲区**：验证覆盖了氢键和 π 堆积，**没覆盖配位键和离子对**——
金属配合物、盐类晶体里片段间距离可能落在 2.0–2.5 Å（共价半径判断通常能认成
「成键」，但 Zn–N 2.4 Å、Na–Cl 2.8 Å 这种弱配位/离子接触处在灰区）。
这两类体系如果判错，B-10 会误报。要彻底确认得拿真实配合物日志来试，
而这类日志公开渠道同样少见。

---

## 十、复跑方式

```bash
# 1. 登录（两跳，需要密码）
python field_test/rsh.py run "hostname"

# 2. 重新生成输入并推到 cu04
python field_test/server/gen_inputs.py
python field_test/remote.py push
python field_test/remote.py gauss      # 并行跑全部 ok_*/fail_*
python field_test/remote.py special    # 依赖前序产物/kill 的用例
python field_test/remote.py fetch      # 拉回日志

# 3b. 结构错误专项 + B-10 的复合物对照组（附录那一节）
python field_test/server/gen_badgeom.py
python field_test/remote.py badgeom    # 6 种明显错的结构 -> field_test/badgeom_out
python field_test/server/gen_complex.py
python field_test/remote.py complex    # 水/苯二聚体 + 非相互作用极限 -> field_test/complex_out

# 3. 部署到 NFS 并在服务器上验收
python field_test/remote.py deploy
python field_test/remote.py pushlogs
# 在 mu01 上：
cd /nfs-cu07-1/mqh/qchem-eval-verify
/nfs-soft/anaconda3/bin/python3.12 field_test/server/verify_rules.py field_test/real
/nfs-soft/anaconda3/bin/python3.12 field_test/server/gen_adversarial.py \
    field_test/real/ok_water_optfreq.log field_test/adversarial
```

---

## 十一、下一步（按性价比）

| 优先级 | 事项 | 说明 |
|---|---|---|
| **高** | B-09 定级：major 还是 critical | 全样本唯一的漏放就是它。提到 critical 会连累「其实没错」的体系，等你拍板 |
| **高** | `--input` 输入文件交叉核对 | 补上 P0 漏判。要改 CLI 接口，等你确认 |
| 已完成 | ~~E-08 逐段比对 route~~ | v0.6 已改：只在段间方法/基组真不一致时报（cu04 实测通过） |
| 中 | 用你们的真实失败 log 校阈值 | 38 条规则的数值阈值至今没有一条被真实失败验证过 |
| 低 | C-08 措辞、嗅探回退 | 不影响判定 |
